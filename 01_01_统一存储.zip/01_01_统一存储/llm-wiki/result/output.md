# 运行输出

执行 `python code/work/main.py --root .` 后，每个 `question/group-*.md` 会生成对应的 `output/group-*-answer.md`，控制台同时输出题目路径、答案路径和题目数量。

索引缓存位于 `code/work/.cache/index.json`，批注修复文件和 Excel 汇总文件位于 `output/fixed/`。
