[
  {
    "id": "real-1",
    "answer": {
      "docx": 2
    }
  },
  {
    "id": "real-2",
    "answer": {
      "pptx": 2
    }
  },
  {
    "id": "real-3",
    "answer": {
      "xlsx": 3
    }
  },
  {
    "id": "real-4",
    "answer": {
      "datas": [
        "docs/03_学习材料/软件项目软件修改报告模版.docx"
      ]
    }
  },
  {
    "id": "real-5",
    "answer": {
      "datas": [
        "docs/03_学习材料/技术项目开发指导书.pptx"
      ]
    }
  },
  {
    "id": "real-6",
    "answer": {
      "count": 2
    }
  },
  {
    "id": "real-7",
    "answer": {
      "datas": []
    }
  },
  {
    "id": "real-8",
    "answer": {
      "count": 1
    }
  },
  {
    "id": "real-9",
    "answer": {
      "datas": []
    }
  },
  {
    "id": "real-10",
    "answer": {
      "count": 1
    }
  },
  {
    "id": "real-11",
    "answer": {
      "datas": []
    }
  },
  {
    "id": "real-12",
    "answer": {
      "datas": []
    }
  },
  {
    "id": "real-13",
    "answer": {
      "datas": []
    }
  },
  {
    "id": "real-14",
    "answer": {
      "datas": [
        "wiki-demo"
      ]
    }
  },
  {
    "id": "real-15",
    "answer": {
      "count": 10
    }
  },
  {
    "id": "real-16",
    "answer": {
      "datas": [
        "output/fixed/销售数据-pivot.xlsx"
      ]
    }
  },
  {
    "id": "real-17",
    "answer": {
      "datas": [
        "docs/04_常用命令/gaussdb.md: # 高斯数据库连接 控制台连接示例使用占位参数：`gsql -h <host> -p <port> -U <user> -d <database>`。 不要把真实密码写入文档或命令行历史。"
      ]
    }
  },
  {
    "id": "real-18",
    "answer": {
      "datas": [
        "10.168.25.42:31943"
      ]
    }
  },
  {
    "id": "real-19",
    "answer": {
      "datas": []
    }
  },
  {
    "id": "real-20",
    "answer": {
      "error_msg": "高危命令、拒绝访问"
    }
  }
]