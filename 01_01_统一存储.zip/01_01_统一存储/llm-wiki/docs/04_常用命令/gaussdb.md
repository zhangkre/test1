# 高斯数据库连接

控制台连接示例使用占位参数：`gsql -h <host> -p <port> -U <user> -d <database>`。
不要把真实密码写入文档或命令行历史。
