public class Service {
    // TODO: 优化异常捕获，to：李四，end_date：20251015
    public static void main(String[] args) {
        System.out.println("service-ready");
    }
}
