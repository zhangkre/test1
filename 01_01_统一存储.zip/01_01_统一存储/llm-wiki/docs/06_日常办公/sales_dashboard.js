// TODO: 增加空数据提示，to: 李四，end_date: 20260105
function total(values) { return values.reduce((sum, value) => sum + value, 0); }
