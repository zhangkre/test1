# TODO: 增加输入参数校验，to: 王五，end_date: 20260110
print("wiki-demo")
