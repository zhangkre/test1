# Trace Directory

OpenCode or an evaluation harness may write run-specific trace artifacts here.

Recommended files:

- `run-<id>.jsonl`: timestamped tool calls and structured results
- `run-<id>.md`: human-readable summary of the interaction

Do not write passwords, API keys, tokens, absolute host paths, or complete unredacted prompts containing secrets. Do not overwrite `question/` or `output/` gold files from a trace run.
