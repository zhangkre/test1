# Interaction Log

This file records the interaction and evaluation protocol for the LLM Wiki Skill.

## Runtime Flow

1. OpenCode loads `.opencode/skills/llm-wiki/SKILL.md`.
2. The Skill locates the project root containing `work/main.py` and `docs/`.
3. Exact operations use `work/run.cmd --root . --ask`.
4. Semantic operations may use `work/run.cmd --root . --evidence` before the model forms the answer.
5. Python performs evidence extraction, Permission checks, document edits, and JSON validation.
6. Modified documents are written only below `output/fixed/`.

## Evaluation Rules

- `question/group-test.md` and `output/group-test-answer.md` are read-only evaluation artifacts.
- Evaluation traces belong under `logs/trace/` and must not overwrite gold files.
- Paths and values must be copied from evidence exactly; the model must not invent or repair filenames.
- Do not record passwords, tokens, API keys, absolute external paths, or unredacted secrets in logs.
