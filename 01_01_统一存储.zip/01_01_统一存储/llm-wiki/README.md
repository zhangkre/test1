# LLM Wiki 输出目录

- `Permission.json`：外部权限黑名单输入。程序只读取该文件，只有命中其中的目录、文件或命令 deny 规则才返回高危拒绝结果。
- `group-*-answer.md`：根据同名 `question/group-*.md` 自动生成的 JSON 答案数组。
- `fixed/`：批注/TODO 修复后的文档和 Excel 汇总文件。程序不会覆盖 `docs` 内的原始文件。

所有路径均相对于当前项目根目录，例如 `docs/05_需求涉及/产品规则.py`。
