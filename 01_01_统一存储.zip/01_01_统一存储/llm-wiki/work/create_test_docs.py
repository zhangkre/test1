from __future__ import annotations

import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
DOCS = ROOT / "llm-wiki" / "docs"


def write_text(relative: str, text: str) -> None:
    path = DOCS / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def create_docx(path: Path) -> None:
    content_types = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
<Override PartName="/word/comments.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.comments+xml"/>
</Types>"""
    rels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>"""
    document = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:body><w:p><w:r><w:t>产品规则详解：报价系统支持客户、产品和折扣字段。</w:t></w:r></w:p>
<w:p><w:r><w:t>数据库连接配置由环境变量提供。</w:t></w:r></w:p><w:sectPr/></w:body></w:document>"""
    comments = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:comments xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:comment w:id="0" w:author="张三" w:date="2025-10-01T08:00:00Z"><w:p><w:r><w:t>todo: 补充产品报价字段，to: 张三，end_date: 20251231</w:t></w:r></w:p></w:comment>
<w:comment w:id="1" w:author="李四" w:date="2025-10-02T08:00:00Z"><w:p><w:r><w:t>应该把旧版折扣说明改成新版规则</w:t></w:r></w:p></w:comment>
</w:comments>"""
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("[Content_Types].xml", content_types)
        archive.writestr("_rels/.rels", rels)
        archive.writestr("word/document.xml", document)
        archive.writestr("word/comments.xml", comments)


def create_pptx(path: Path) -> None:
    content_types = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/ppt/slides/slide1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/><Override PartName="/ppt/comments/comment1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.comment+xml"/>
</Types>"""
    slide = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:sld xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"><p:cSld><p:spTree><p:sp><p:txBody><a:p xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:r><a:t>销售分析与客户增长计划</a:t></a:r></a:p></p:txBody></p:sp></p:spTree></p:cSld></p:sld>"""
    comments = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:cmLst xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><p:cm authorId="0" idx="1"><p:txBody><a:p><a:r><a:t>todo: 增加区域销售趋势图，to: 王五，end_date: 20260115</a:t></a:r></a:p></p:txBody></p:cm></p:cmLst>"""
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("[Content_Types].xml", content_types)
        archive.writestr("ppt/slides/slide1.xml", slide)
        archive.writestr("ppt/comments/comment1.xml", comments)


def create_xlsx(path: Path) -> None:
    from openpyxl import Workbook
    from openpyxl.comments import Comment

    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Sales"
    sheet.append(["Region", "Product", "Amount"])
    sheet.append(["华东", "数据库服务", 120000])
    sheet.append(["华南", "办公套件", 80000])
    sheet.append(["华东", "办公套件", 95000])
    sheet["C2"].comment = Comment("TODO：补充税率字段，TO：赵六，END_DATE：20251220", "赵六")
    workbook.save(path)
    workbook.close()


def main() -> None:
    write_text("00_业务总结/业务总览.md", """# 业务总览

本项目涉及产品报价、销售分析、数据库配置和办公自动化。产品规则文档可能位于技术总结目录，目录名称不能作为唯一判断依据。
""")
    write_text("01_技术总结/service.java", """public class Service {
    // TODO: 优化异常捕获，to：李四，end_date：20251015
    public static void main(String[] args) {
        System.out.println(\"service-ready\");
    }
}
""")
    write_text("02_环境信息/env_config.xml", """<?xml version="1.0"?><configuration><database><host>localhost</host><port>5432</port><user>readonly</user></database><note>密码由安全配置中心注入，不在文件中保存。</note></configuration>""")
    write_text("03_学习材料/python_demo.py", """# TODO: 增加输入参数校验，to: 王五，end_date: 20260110
print(\"wiki-demo\")
""")
    write_text("04_常用命令/gaussdb.md", """# 高斯数据库连接

控制台连接示例使用占位参数：`gsql -h <host> -p <port> -U <user> -d <database>`。
不要把真实密码写入文档或命令行历史。
""")
    write_text("05_需求涉及/product_rules.html", """<!doctype html><html><body><h1>产品报价规则</h1><p>报价字段包含客户、产品、数量和折扣。</p><!-- TODO: 补充折扣上限说明，to: 张三，end_date: 20251231 --></body></html>""")
    write_text("06_日常办公/sales_dashboard.js", """// TODO: 增加空数据提示，to: 李四，end_date: 20260105
function total(values) { return values.reduce((sum, value) => sum + value, 0); }
""")
    write_text("07_其他/free_note.txt", """这是不纳入代码 TODO 范围的普通资料文件，可作为业务检索输入。关键词：客户画像、销售预测、数据库。
""")
    write_text("07_其他/archive.bin", "binary test placeholder; not a TODO source\n")
    office = DOCS / "05_需求涉及"
    office.mkdir(parents=True, exist_ok=True)
    create_docx(office / "产品规则详解.docx")
    create_pptx(office / "销售分析.pptx")
    create_xlsx(office / "销售数据.xlsx")
    # Legacy suffix fixtures are intentionally text placeholders; real OLE samples can replace them for parser tests.
    write_text("05_需求涉及/legacy.doc", "legacy .doc fixture placeholder\n")
    write_text("05_需求涉及/legacy.ppt", "legacy .ppt fixture placeholder\n")
    write_text("05_需求涉及/legacy.pps", "legacy .pps fixture placeholder\n")
    write_text("05_需求涉及/legacy.ppts", "legacy .ppts fixture placeholder\n")
    write_text("05_需求涉及/legacy.xls", "legacy .xls fixture placeholder\n")


if __name__ == "__main__":
    main()
