from __future__ import annotations

import re
import shutil
import zipfile
from pathlib import Path

from .models import Document, Layout
from .security import SecurityPolicy


def _safe_target(layout: Layout, source: Document) -> Path:
    source_path = Path(source.path)
    try:
        relative = source_path.relative_to(layout.docs.relative_to(layout.root))
    except ValueError:
        relative = Path(source_path.name)
    return layout.output / "fixed" / relative


def _remove_code_comments(text: str, annotations: list) -> str:
    replacements: list[tuple[int, str]] = []
    for annotation in annotations:
        if not annotation.location or not annotation.location.startswith("line:"):
            continue
        try:
            line_no = int(annotation.location.split(":", 1)[1]) - 1
        except (ValueError, IndexError):
            continue
        lines = text.splitlines(keepends=True)
        if 0 <= line_no < len(lines):
            line = lines[line_no]
            if "TODO" in line.upper():
                replacements.append((line_no, re.sub(r"\s*(?://|#)\s*TODO.*$", "", line, flags=re.I)))
    lines = text.splitlines(keepends=True)
    for line_no, value in replacements:
        lines[line_no] = value
    return "".join(lines)


def fix_document(layout: Layout, document: Document, policy: SecurityPolicy) -> str | None:
    source = layout.root / document.path
    target = _safe_target(layout, document)
    relative_target = target.relative_to(layout.root).as_posix()
    if policy.path_denied(document.path) or policy.path_denied(relative_target):
        return None
    target.parent.mkdir(parents=True, exist_ok=True)
    suffix = source.suffix.lower()
    if suffix in {".py", ".java", ".js", ".html", ".xml", ".md"}:
        text = source.read_text(encoding="utf-8-sig", errors="replace")
        target.write_text(_remove_code_comments(text, document.annotations), encoding="utf-8")
    elif suffix == ".xlsx":
        from openpyxl import load_workbook
        workbook = load_workbook(source)
        try:
            for sheet in workbook.worksheets:
                for row in sheet.iter_rows():
                    for cell in row:
                        if cell.comment:
                            cell.comment = None
            workbook.save(target)
        finally:
            workbook.close()
    elif suffix == ".docx":
        _copy_ooxml_without_comments(source, target, "word/comments.xml")
    elif suffix == ".pptx":
        _copy_ooxml_without_prefix(source, target, "ppt/comments/")
    elif suffix in {".doc", ".ppt", ".pps", ".ppts"}:
        # Preserve the requested legacy Office output path. The binary source
        # is copied because editing OLE comment streams safely needs Office.
        shutil.copy2(source, target)
    else:
        shutil.copy2(source, target)
    return relative_target


def _copy_ooxml_without_comments(source: Path, target: Path, comment_member: str) -> None:
    with zipfile.ZipFile(source) as src, zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as dst:
        for item in src.infolist():
            if item.filename != comment_member:
                dst.writestr(item, src.read(item.filename))


def _copy_ooxml_without_prefix(source: Path, target: Path, prefix: str) -> None:
    with zipfile.ZipFile(source) as src, zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as dst:
        for item in src.infolist():
            if not item.filename.startswith(prefix):
                dst.writestr(item, src.read(item.filename))


def create_pivot_summary(layout: Layout, document: Document, policy: SecurityPolicy) -> str | None:
    from openpyxl import Workbook, load_workbook
    source = layout.root / document.path
    target = layout.output / "fixed" / f"{source.stem}-pivot.xlsx"
    relative = target.relative_to(layout.root).as_posix()
    if policy.path_denied(document.path) or policy.path_denied(relative):
        return None
    target.parent.mkdir(parents=True, exist_ok=True)
    try:
        source_book = load_workbook(source, read_only=True, data_only=True)
    except Exception:
        return None
    output = Workbook()
    result = output.active
    result.title = "Pivot Summary"
    result.append(["Sheet", "Row count", "Column count", "Numeric sum"])
    try:
        for sheet in source_book.worksheets:
            numeric_sum = 0.0
            row_count = 0
            for row in sheet.iter_rows(values_only=True):
                if any(value is not None for value in row):
                    row_count += 1
                numeric_sum += sum(float(value) for value in row if isinstance(value, (int, float)))
            result.append([sheet.title, row_count, sheet.max_column, numeric_sum])
        if not source_book.worksheets:
            return None
        output.save(target)
    finally:
        source_book.close()
        output.close()
    return relative
