from __future__ import annotations

import json
from pathlib import Path

from .extractors import INDEXED_SUFFIXES, extract_document
from .models import Document, Layout
from .security import SecurityPolicy


class WikiIndex:
    def __init__(self, documents: list[Document]):
        self.documents = documents

    @classmethod
    def build(cls, layout: Layout, policy: SecurityPolicy) -> "WikiIndex":
        documents: list[Document] = []
        if not layout.docs.exists():
            return cls(documents)
        for path in sorted(item for item in layout.docs.rglob("*") if item.is_file()):
            if path.name.startswith("~$"):
                continue
            relative = path.relative_to(layout.root).as_posix()
            if policy.path_denied(relative):
                continue
            if path.suffix.lower() not in INDEXED_SUFFIXES:
                # Other file types are discoverable by name but excluded from TODO/comment questions.
                documents.append(Document(path=relative, suffix=path.suffix.lower().lstrip("."), metadata={"metadata_only": True}))
                continue
            document = extract_document(path, relative)
            if policy.content_is_untrusted(document.text):
                # Keep only an auditable path marker. The body must not enter
                # retrieval, while action requests targeting this file still
                # need to be rejected by the policy layer.
                document.text = ""
                document.annotations = []
                document.metadata["restricted"] = True
            documents.append(document)
        return cls(documents)

    def save(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps([doc.to_dict() for doc in self.documents], ensure_ascii=False, indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path: Path) -> "WikiIndex":
        value = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(value, list):
            return cls([])
        return cls([Document.from_dict(item) for item in value if isinstance(item, dict)])

    def count_suffix(self, suffix: str) -> int:
        return sum(doc.suffix == suffix.lstrip(".").casefold() for doc in self.documents)
