from __future__ import annotations

import argparse
import json
from pathlib import Path

from .engine import AnswerEngine, read_questions
from .indexer import WikiIndex
from .models import Layout
from .security import DENIED, SecurityPolicy


def discover_layout(root: Path) -> Layout:
    root = root.resolve()
    standalone = (root / "docs").is_dir()
    docs = root / "docs" if standalone else root / "llm-wiki" / "docs"
    questions = root / "question" if standalone else root / "question"
    output = root / "output" if standalone else root / "output"
    permission = root / "Permission.json" if standalone else root / "output" / "Permission.json"
    if not permission.exists() and (output / "Permission.json").exists():
        permission = output / "Permission.json"
    return Layout(
        root=root,
        docs=docs,
        questions=questions,
        output=output,
        permission=permission,
        cache=(root / "work" / ".cache" / "index.json") if standalone else (root / "code" / "work" / ".cache" / "index.json"),
    )


def parser() -> argparse.ArgumentParser:
    value = argparse.ArgumentParser(description="Offline safety-first LLM Wiki")
    value.add_argument("--root", type=Path, default=Path.cwd(), help="Project root (self-contained docs/ or outer llm-wiki/docs layout)")
    value.add_argument("--questions", type=Path, help="Process one question JSON/Markdown file")
    value.add_argument("--ask", nargs="?", const="", help="Answer one question and print only the required answer JSON")
    value.add_argument("--evidence", nargs="?", const="", help="Return bounded read-only evidence for LLM reasoning")
    value.add_argument("--index-only", action="store_true")
    return value


def run(args: argparse.Namespace) -> int:
    layout = discover_layout(args.root)
    policy = SecurityPolicy.load(layout.permission)
    index = WikiIndex.build(layout, policy)
    index.save(layout.cache)
    if args.ask is not None:
        answer = AnswerEngine(layout, index, policy).answer({"title": args.ask})
        print(json.dumps(answer, ensure_ascii=False))
        return 0
    if args.evidence is not None:
        if policy.reject_question(args.evidence):
            print(json.dumps({"blocked": True, "answer": dict(DENIED)}, ensure_ascii=False))
            return 0
        print(json.dumps(AnswerEngine(layout, index, policy).evidence(args.evidence), ensure_ascii=False))
        return 0
    if args.index_only:
        print(json.dumps({"indexed": len(index.documents)}, ensure_ascii=False))
        return 0

    layout.output.mkdir(parents=True, exist_ok=True)
    files = [args.questions] if args.questions else sorted(layout.questions.glob("group-*.md"))
    if not files:
        print(json.dumps({"indexed": len(index.documents), "questions": 0}, ensure_ascii=False))
        return 0
    engine = AnswerEngine(layout, index, policy)
    for path in files:
        question_path = path if path.is_absolute() else layout.root / path
        answers = []
        try:
            questions = read_questions(question_path)
        except (OSError, ValueError, json.JSONDecodeError) as error:
            print(json.dumps({"error": str(error), "questions": str(question_path)}, ensure_ascii=False))
            return 2
        for item in questions:
            safe_item = item if isinstance(item, dict) else {}
            answers.append({"id": safe_item.get("id"), "answer": engine.answer(safe_item)})
        target = layout.output / f"{question_path.stem}-answer.md"
        target.write_text(json.dumps(answers, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps({"questions": str(question_path), "output": str(target), "count": len(answers)}, ensure_ascii=False))
    return 0


def main() -> int:
    return run(parser().parse_args())
