from __future__ import annotations

import re

from .models import Document


def normalize(text: str) -> str:
    return re.sub(r"[^\w\u4e00-\u9fff]+", "", str(text or "")).casefold()


def query_terms(question: str) -> list[str]:
    phrases = re.findall(r"[\u4e00-\u9fff]{2,}|[a-zA-Z0-9_.-]{2,}", question)
    terms: list[str] = []
    stop = {"文件", "路径", "项目", "全部", "统计", "查询", "如何", "控制台"}
    for item in phrases:
        value = normalize(item)
        if value in stop:
            continue
        terms.append(value)
        if re.fullmatch(r"[\u4e00-\u9fff]+", value) and len(value) > 4:
            # Chinese questions do not contain spaces; short n-grams recover reordered phrases.
            terms.extend(value[index:index + 2] for index in range(len(value) - 1))
            terms.extend(value[index:index + 4] for index in range(len(value) - 3))
    return list(dict.fromkeys(term for term in terms if term and term not in stop))


def rank(documents: list[Document], question: str, limit: int = 20) -> list[Document]:
    terms = query_terms(question)
    scored: list[tuple[int, str, Document]] = []
    for doc in documents:
        if doc.metadata.get("restricted"):
            continue
        normalized_path = normalize(doc.path)
        haystack = normalize(" ".join([doc.path or "", doc.text or "", " ".join(str(a.text or "") for a in doc.annotations)]))
        matched = [term for term in terms if term and term in haystack]
        ascii_terms = [term for term in terms if re.fullmatch(r"[a-z0-9_.-]+", term)]
        if any(term not in haystack for term in ascii_terms):
            continue
        # Distinct concepts dominate; repetitions in long documents add only a small bonus.
        score = sum(len(term) ** 2 for term in matched)
        score += sum(len(term) * 4 for term in matched if term in normalized_path)
        score += sum(min(haystack.count(term), 3) for term in matched)
        if score:
            scored.append((score, doc.path, doc))
    ordered = sorted(scored, key=lambda row: (-row[0], row[1]))
    if not ordered:
        return []
    # Drop incidental keyword matches while retaining similarly relevant documents.
    threshold = max(1, int(ordered[0][0] * 0.8))
    return [item[2] for item in ordered if item[0] >= threshold][:limit]
