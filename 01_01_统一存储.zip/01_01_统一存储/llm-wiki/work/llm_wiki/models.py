from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class Annotation:
    text: str
    kind: str
    author: str | None = None
    end_date: str | None = None
    location: str | None = None


@dataclass
class Document:
    path: str
    suffix: str
    text: str = ""
    annotations: list[Annotation] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "Document":
        raw = dict(value) if isinstance(value, dict) else {}
        annotations = raw.get("annotations")
        raw["annotations"] = [Annotation(**item) for item in annotations if isinstance(item, dict)] if isinstance(annotations, list) else []
        raw["metadata"] = raw.get("metadata") if isinstance(raw.get("metadata"), dict) else {}
        raw["path"] = str(raw.get("path") or "")
        raw["suffix"] = str(raw.get("suffix") or "")
        raw["text"] = str(raw.get("text") or "")
        allowed = {"path", "suffix", "text", "annotations", "metadata"}
        return cls(**{key: raw[key] for key in allowed})


@dataclass(frozen=True)
class Layout:
    root: Path
    docs: Path
    questions: Path
    output: Path
    permission: Path
    cache: Path
