from __future__ import annotations

import csv
import re
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

from .annotations import extract_code_annotations, parse_annotation
from .models import Annotation, Document


TEXT_SUFFIXES = {".xml", ".java", ".py", ".html", ".htm", ".md", ".js", ".json", ".txt", ".csv", ".yaml", ".yml"}
CODE_SUFFIXES = {".xml", ".java", ".py", ".html", ".htm", ".md", ".js"}
OFFICE_SUFFIXES = {".docx", ".pptx", ".xlsx"}
LEGACY_SUFFIXES = {".doc", ".ppt", ".pps", ".xls"}
INDEXED_SUFFIXES = TEXT_SUFFIXES | OFFICE_SUFFIXES | LEGACY_SUFFIXES | {".ppts"}

NS = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main", "a": "http://schemas.openxmlformats.org/drawingml/2006/main"}


def _read_text(path: Path) -> str:
    for encoding in ("utf-8-sig", "utf-8", "gb18030", "latin-1"):
        try:
            return path.read_text(encoding=encoding)
        except UnicodeDecodeError:
            continue
        except OSError:
            return ""
    return ""


def _xml_text(raw: bytes) -> str:
    try:
        root = ET.fromstring(raw)
        return " ".join(part.strip() for part in root.itertext() if part.strip())
    except ET.ParseError:
        return raw.decode("utf-8", "replace")


def _zip_member_text(archive: zipfile.ZipFile, prefix: str, suffix: str = ".xml") -> str:
    chunks: list[str] = []
    for name in archive.namelist():
        if name.startswith(prefix) and name.endswith(suffix):
            chunks.append(_xml_text(archive.read(name)))
    return "\n".join(chunks)


def _word(path: Path) -> tuple[str, list[Annotation]]:
    with zipfile.ZipFile(path) as archive:
        document_root = None
        if "word/document.xml" in archive.namelist():
            document_root = ET.fromstring(archive.read("word/document.xml"))
            text = " ".join(part.strip() for part in document_root.itertext() if part.strip())
        else:
            text = ""
        comments: list[Annotation] = []
        referenced_ids: set[str] = set()
        if document_root is not None:
            id_key = f"{{{NS['w']}}}id"
            for tag in ("commentRangeStart", "commentRangeEnd", "commentReference"):
                for item in document_root.findall(f".//w:{tag}", NS):
                    value = item.get(id_key)
                    if value is not None:
                        referenced_ids.add(value)
        if "word/comments.xml" in archive.namelist() and referenced_ids:
            root = ET.fromstring(archive.read("word/comments.xml"))
            author_key = f"{{{NS['w']}}}author"
            date_key = f"{{{NS['w']}}}date"
            id_key = f"{{{NS['w']}}}id"
            for item in root.findall("w:comment", NS):
                if item.get(id_key) not in referenced_ids:
                    continue
                author = item.get(author_key)
                date = item.get(date_key)
                body = " ".join(t.strip() for t in item.itertext() if t.strip())
                annotation = parse_annotation(body, "office_comment", f"comment:{item.get(id_key, '')}")
                annotation.author = annotation.author or author
                annotation.end_date = annotation.end_date or (date or "")[:10].replace("-", "") or None
                comments.append(annotation)
    return text, comments


def _ppt(path: Path) -> tuple[str, list[Annotation]]:
    with zipfile.ZipFile(path) as archive:
        comments: list[Annotation] = []
        for name in archive.namelist():
            if name.startswith("ppt/comments/") and name.endswith(".xml"):
                try:
                    root = ET.fromstring(archive.read(name))
                    for index, item in enumerate(root):
                        body = " ".join(part.strip() for part in item.itertext() if part.strip())
                        if body:
                            comments.append(parse_annotation(body, "office_comment", f"{name}:{index + 1}"))
                except ET.ParseError:
                    continue
        return _zip_member_text(archive, "ppt/slides/"), comments


def _xlsx(path: Path) -> tuple[str, list[Annotation]]:
    try:
        from openpyxl import load_workbook
    except ImportError:
        return "", []
    workbook = load_workbook(path, read_only=False, data_only=False)
    chunks: list[str] = []
    comments: list[Annotation] = []
    try:
        for sheet in workbook.worksheets:
            for row in sheet.iter_rows():
                values = []
                for cell in row:
                    if cell.value is not None:
                        values.append(f"{cell.coordinate}={cell.value}")
                    if cell.comment and cell.comment.text:
                        annotation = parse_annotation(cell.comment.text, "office_comment", f"{sheet.title}!{cell.coordinate}")
                        annotation.author = annotation.author or cell.comment.author
                        comments.append(annotation)
                if values:
                    chunks.append(f"[{sheet.title}] " + " | ".join(values))
    finally:
        workbook.close()
    return "\n".join(chunks), comments


def _legacy_xls(path: Path) -> tuple[str, list[Annotation]]:
    """Read BIFF workbooks and their classic cell notes without external software."""
    try:
        import xlrd
        book = xlrd.open_workbook(path, formatting_info=False)
    except (ImportError, OSError, ValueError, TypeError):
        return "", []
    chunks: list[str] = []
    annotations: list[Annotation] = []
    for sheet in book.sheets():
        for row_index in range(sheet.nrows):
            values = [str(value) for value in sheet.row_values(row_index) if value not in (None, "")]
            if values:
                chunks.append(f"[{sheet.name}] " + " | ".join(values))
        for (row_index, col_index), note in getattr(sheet, "cell_note_map", {}).items():
            text = getattr(note, "text", "")
            if text:
                location = f"{sheet.name}!R{row_index + 1}C{col_index + 1}"
                annotations.append(parse_annotation(text, "office_comment", location))
    return "\n".join(chunks), annotations


def _read_ole_strings(raw: bytes) -> str:
    """Extract human-readable runs from legacy Office streams without executing content."""
    candidates: list[str] = []
    for encoding in ("utf-16le", "utf-8", "gb18030", "latin-1"):
        decoded = raw.decode(encoding, "ignore")
        candidates.extend(re.findall(r"[\u4e00-\u9fffA-Za-z0-9][\u4e00-\u9fffA-Za-z0-9_.,，。:：;；!?（）() /\\-]{3,}", decoded))
    return "\n".join(dict.fromkeys(item.strip() for item in candidates if item.strip()))


def _legacy_ole(path: Path) -> tuple[str, list[Annotation]]:
    """Best-effort text/TODO extraction for binary Word and PowerPoint OLE documents."""
    try:
        import olefile
        container = olefile.OleFileIO(path)
    except (ImportError, OSError, ValueError, TypeError):
        return _legacy_raw_text(path)
    chunks: list[str] = []
    try:
        for stream in container.listdir(streams=True, storages=False):
            name = "/".join(stream)
            if not any(token in name.casefold() for token in ("worddocument", "powerpoint document", "comments", "notes")):
                continue
            try:
                chunks.append(_read_ole_strings(container.openstream(stream).read()))
            except OSError:
                continue
    finally:
        container.close()
    text = "\n".join(chunk for chunk in chunks if chunk)
    annotations = extract_code_annotations(text)
    # Legacy Office comments are often stored as bare text in the OLE stream,
    # without a source-code comment marker. Keep only structured TODO records.
    structured = re.findall(
        r"(?i)todo\s*[：:]\s*[^\r\n\x00]{1,240}?(?=\r?\n|$|\x0b|\x0c)",
        text,
    )
    seen = {(item.text, item.author, item.end_date) for item in annotations}
    for value in structured:
        item = parse_annotation(value, "office_comment", "legacy:todo")
        key = (item.text, item.author, item.end_date)
        if item.author and item.end_date and key not in seen:
            annotations.append(item)
            seen.add(key)
    if not annotations:
        raw_text, raw_annotations = _legacy_raw_text(path)
        if raw_annotations:
            return raw_text, raw_annotations
    return text, annotations


def _legacy_raw_text(path: Path) -> tuple[str, list[Annotation]]:
    """Fallback for OLE files whose comment stream is not exposed by olefile."""
    try:
        raw = path.read_bytes()
    except OSError:
        return "", []
    chunks: list[str] = []
    for encoding in ("utf-16le", "gb18030", "utf-8"):
        decoded = raw.decode(encoding, "ignore")
        chunks.extend(re.findall(r"(?i)todo\s*[：:][^\x00\r\n]{1,240}", decoded))
    text = "\n".join(dict.fromkeys(chunk.strip() for chunk in chunks if chunk.strip()))
    annotations: list[Annotation] = []
    for index, value in enumerate(text.splitlines(), 1):
        item = parse_annotation(value, "office_comment", f"legacy:todo:{index}")
        if item.author and item.end_date:
            annotations.append(item)
    return text, annotations


def extract_document(path: Path, display_path: str | None = None) -> Document:
    suffix = path.suffix.lower()
    relative = display_path or path.name
    document = Document(path=relative.replace("\\", "/"), suffix=suffix.lstrip("."))
    try:
        if suffix in TEXT_SUFFIXES:
            document.text = _read_text(path)
            if suffix in CODE_SUFFIXES:
                document.annotations = extract_code_annotations(document.text)
        elif suffix == ".docx":
            document.text, document.annotations = _word(path)
        elif suffix == ".pptx":
            document.text, document.annotations = _ppt(path)
        elif suffix == ".xlsx":
            document.text, document.annotations = _xlsx(path)
        elif suffix == ".xls":
            document.text, document.annotations = _legacy_xls(path)
        elif suffix in LEGACY_SUFFIXES or suffix == ".ppts":
            document.text, document.annotations = _legacy_ole(path)
    except Exception as error:
        # One malformed or unsupported file must not abort indexing hundreds of documents.
        document.metadata["extract_error"] = "unreadable"
        document.metadata["extract_error_type"] = type(error).__name__
    return document


def extract_csv(path: Path) -> str:
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as stream:
            return "\n".join(" | ".join(row) for row in csv.reader(stream))
    except OSError:
        return ""
