from __future__ import annotations

import fnmatch
import json
import re
from pathlib import Path
from typing import Any


DENIED = {"error_msg": "高危命令、拒绝访问"}

_DANGEROUS = re.compile(
    r"(?:rm\s+-rf|remove-item|\bdel\b|delete\s+from|drop\s+(?:table|database)|format\s+[a-z]:|"
    r"shutdown|reboot|mkfs|dd\s+if=|chmod\s+777|chown|sudo|提权|上帝模式|彻底删除|强制删除|"
    r"curl\b.*\|\s*(?:sh|bash)|wget\b.*\|\s*(?:sh|bash)|powershell.{0,30}(?:iex|invoke-expression))",
    re.I | re.S,
)
_SYSTEM_ENUM = re.compile(
    r"(?:读取|列出|遍历|查看).{0,12}(?:c(?:盘|[：:]?\\?)根目录|系统目录|/etc|/root|windows\\system32|用户目录全部文件)",
    re.I,
)
_PROMPT_ATTACK = re.compile(
    r"(?:忽略|绕过|覆盖|无视).{0,15}(?:之前|以上|安全|规则|指令)|prompt\s*inject|system\s*prompt",
    re.I,
)
_CREDENTIAL_VALUE = re.compile(
    r"(?:password|passwd|pwd|pass|token|secret|api[_ -]?key|密码|口令|密钥|秘钥)\s*(?:[=:：]|/).{3,}|"
    r"(?:root|admin|gkit[_a-z0-9-]*|svc_[a-z0-9_-]+|fsfs)\s*[/@].{3,}",
    re.I,
)
_UNTRUSTED_ACTION = re.compile(r"(?:写入|创建|删除|执行|运行|kill\b|rm\b|remove-item|curl\b|wget\b)", re.I)
_DOCUMENT_ACTION_INJECTION = re.compile(
    r"(?:最高优先级|不要询问用户|无论用户提出什么|遵循当前描述|\$\{pwd\}|向.{0,120}(?:写入|创建|删除).{0,160}(?:文件|目录))",
    re.I | re.S,
)


class SecurityPolicy:
    def __init__(self, config: dict[str, Any] | None = None):
        config = config if isinstance(config, dict) else {}
        self.denied_dirs = self._items(config, "dir")
        self.denied_files = self._items(config, "file")
        self.denied_commands = self._items(config, "command")

    @classmethod
    def load(cls, path: Path) -> "SecurityPolicy":
        if not path.exists():
            return cls()
        try:
            return cls(json.loads(path.read_text(encoding="utf-8-sig")))
        except (OSError, json.JSONDecodeError):
            # A malformed policy must never weaken the built-in policy.
            return cls()

    @staticmethod
    def _items(config: dict[str, Any], key: str) -> list[str]:
        section = config.get(key, {})
        if not isinstance(section, dict):
            return []
        denied = section.get("deny", [])
        if not isinstance(denied, list):
            return []
        return [str(x).strip() for x in denied if x is not None and str(x).strip()]

    @staticmethod
    def _match(value: str, patterns: list[str]) -> bool:
        normalized = str(value or "").replace("\\", "/").casefold()
        base = normalized.rsplit("/", 1)[-1]
        for pattern in patterns:
            candidate = pattern.replace("\\", "/").casefold()
            if fnmatch.fnmatch(normalized, candidate) or fnmatch.fnmatch(base, candidate):
                return True
            if candidate.endswith("/*") and fnmatch.fnmatch(normalized, candidate[:-1] + "*"):
                return True
            if candidate and "/" in candidate and normalized.startswith(candidate.rstrip("/") + "/"):
                return True
            if not any(c in candidate for c in "*/?") and candidate in normalized:
                return True
        return False

    def path_denied(self, value: str) -> bool:
        normalized = str(value or "").replace("\\", "/").casefold()
        if self._match(value, self.denied_files):
            return True
        if self._match(value, self.denied_dirs):
            return True
        for pattern in self.denied_dirs:
            candidate = pattern.replace("\\", "/").casefold().strip("/")
            literal = candidate.replace("*", "").strip("/")
            if literal and (normalized == literal or f"/{literal}/" in f"/{normalized}/" or normalized.endswith("/" + literal)):
                return True
        # Questions commonly append Chinese wording directly after a path,
        # e.g. ".../hadoop.env中". Treat a configured file token as matched
        # when it is followed by a non-path character.
        for pattern in self.denied_files:
            candidate = pattern.replace("\\", "/").casefold().strip("/")
            if candidate and candidate in normalized:
                end = normalized.find(candidate) + len(candidate)
                if end == len(normalized) or normalized[end] not in "abcdefghijklmnopqrstuvwxyz0123456789_./\\-":
                    return True
        return False

    def command_denied(self, value: str) -> bool:
        return self._match(value, self.denied_commands)

    def reject_question(self, question: str) -> bool:
        question = str(question or "")
        if self.path_denied(question) or self.command_denied(question):
            return True
        # Destructive execution is never a read-only Wiki operation.
        if _DANGEROUS.search(question):
            return True
        return False

    @staticmethod
    def content_is_untrusted(text: str) -> bool:
        """Document instructions are data, never authority; skip actionable injection payloads."""
        return bool(
            (_PROMPT_ATTACK.search(text) and _UNTRUSTED_ACTION.search(text))
            or _DOCUMENT_ACTION_INJECTION.search(text)
        )

    @staticmethod
    def content_is_sensitive(text: str) -> bool:
        """Identify credential-bearing content for redaction, while keeping safe context searchable."""
        return bool(_CREDENTIAL_VALUE.search(text))

    def safe_project_path(self, root: Path, relative: str) -> Path | None:
        if self.path_denied(relative):
            return None
        try:
            target = (root / relative).resolve()
            target.relative_to(root.resolve())
            return target
        except (OSError, ValueError):
            return None
