from __future__ import annotations

import ast
import json
import re
from pathlib import Path
from typing import Any

from .fixer import create_pivot_summary, fix_document
from .indexer import WikiIndex
from .models import Document, Layout
from .retrieval import normalize, rank
from .security import DENIED, SecurityPolicy


COUNT_SUFFIXES = ("doc", "docx", "ppt", "pptx", "ppts", "xls", "xlsx", "xml", "java", "py", "html", "md", "js")


class AnswerEngine:
    def __init__(self, layout: Layout, index: WikiIndex, policy: SecurityPolicy):
        self.layout = layout
        self.index = index
        self.policy = policy

    def answer(self, item: dict[str, Any] | None) -> dict[str, Any]:
        item = item if isinstance(item, dict) else {}
        question = str(item.get("title") or "").strip()
        if not question:
            return {"datas": []}
        if self.policy.reject_question(question):
            return dict(DENIED)

        candidates = rank(self.index.documents, question)
        named = self._named_documents(question)
        if self._targets_untrusted_document(question):
            return dict(DENIED)
        if named:
            # An explicitly named file is a hard scope, not merely a ranking hint.
            candidates = named

        if re.search(r"批注|todo", question, re.I):
            owner = self._owner(question)
            if owner:
                candidates = [doc for doc in self.index.documents if any(owner == (a.author or "").strip() for a in doc.annotations)]
            if re.search(r"修复|修改|优化整理|处理批注|完成todo", question, re.I):
                return self._fix(candidates)
            if not named and re.search(r"全项目|全部|所有|整体", question):
                candidates = [doc for doc in self.index.documents if not doc.metadata.get("restricted")]
            return self._annotations(candidates, question)

        suffix = self._count_suffix(question)
        if suffix:
            return {suffix: self.index.count_suffix(suffix)}

        if re.search(r"透视|pivot|汇总图", question, re.I):
            excel = next((doc for doc in candidates if doc.suffix == "xlsx"), None)
            if excel:
                try:
                    target = create_pivot_summary(self.layout, excel, self.policy)
                except Exception:
                    target = None
                return {"datas": [target]} if target else dict(DENIED)

        if re.search(r"运行结果|执行结果|输出结果", question, re.I):
            result = self._static_result(candidates, question)
            return {"datas": [result]} if result is not None else {"datas": []}

        if re.search(r"密码|口令|密钥|token|secret|credential", question, re.I):
            return self._credential_answer(named or candidates, question)

        if re.search(r"路径|在哪里|文件名称|哪些文件|找出", question, re.I):
            return {"datas": [doc.path for doc in candidates]}

        return {"datas": self._snippets(candidates, question)}

    def evidence(self, question: str) -> dict[str, Any]:
        """Return bounded source evidence for an LLM to interpret."""
        question = str(question or "").strip()
        if not question:
            return {"question": question, "sources": []}
        named = self._named_documents(question)
        candidates = named or rank(self.index.documents, question)
        owner = self._owner(question)
        if owner:
            candidates = [
                doc for doc in self.index.documents
                if any(owner == (item.author or "").strip() for item in doc.annotations)
            ]
        return {
            "question": question,
            "sources": [
                {
                    "path": doc.path,
                    "suffix": doc.suffix,
                    "text": " ".join(str(doc.text or "").split())[:2000],
                    "annotations": [
                        {"todo": item.text, "to": item.author, "end_date": item.end_date, "location": item.location}
                        for item in doc.annotations[:30]
                    ],
                }
                for doc in candidates[:12]
            ],
        }

    def _count_suffix(self, question: str) -> str | None:
        if not re.search(r"数量|多少|统计", question):
            return None
        for suffix in sorted(COUNT_SUFFIXES, key=len, reverse=True):
            if re.search(rf"(?<![a-z])\.?{re.escape(suffix)}(?![a-z])", question, re.I):
                return suffix
        return None

    def _named_documents(self, question: str) -> list[Document]:
        normalized_question = normalize(question)
        found = []
        for doc in self.index.documents:
            if doc.metadata.get("restricted"):
                continue
            filename = Path(doc.path).name
            stem = Path(filename).stem
            if normalize(filename) in normalized_question or (len(stem) >= 2 and normalize(stem) in normalized_question):
                found.append(doc)
        return found

    def _annotations(self, candidates: list[Document], question: str) -> dict[str, Any]:
        owner = self._owner(question)
        date = re.search(r"(?:截止|日期|end_date)\s*[：:]?\s*(\d{8})", question, re.I)
        annotations = []
        for doc in candidates:
            for annotation in doc.annotations:
                if owner and owner not in (annotation.author or ""):
                    continue
                if date and annotation.end_date != date.group(1):
                    continue
                item = {"todo": annotation.text, "to": annotation.author, "end_date": annotation.end_date}
                if not owner:
                    item.update({"path": doc.path, "location": annotation.location})
                annotations.append(item)
        if re.search(r"数量|多少", question) or (
            re.search(r"统计", question) and not re.search(r"列表|清单", question)
        ):
            return {"count": len(annotations)}
        return {"datas": annotations}

    def _fix(self, candidates: list[Document]) -> dict[str, Any]:
        source = next((doc for doc in candidates if doc.annotations), None)
        if not source:
            return {"datas": []}
        try:
            target = fix_document(self.layout, source, self.policy)
        except Exception:
            target = None
        if not target:
            return dict(DENIED)
        return {"datas": [{"source": source.path, "target": target}]}

    @staticmethod
    def _owner(question: str) -> str | None:
        match = re.search(
            r"(?:待|责任人为)\s*([\u4e00-\u9fff]{2,4}?)"
            r"(?=\s*(?:处理|负责|的|TODO|批注))",
            question,
            re.I,
        )
        return match.group(1) if match else None

    @staticmethod
    def _credential_answer(documents: list[Document], question: str) -> dict[str, Any]:
        url = re.search(r"https?://[^\s/]+:\d+", question, re.I)
        user = re.search(r"([A-Za-z][A-Za-z0-9_-]+)\s*(?:用户|账号|帐号)", question, re.I)
        values = []
        for doc in documents:
            for line in str(doc.text or "").splitlines():
                if url and url.group(0) not in line:
                    continue
                if user and user.group(1) not in line:
                    continue
                match = re.search(rf"{re.escape(user.group(1))}/([^\s]+)" if user else r"(?:密码|pass(?:word)?|pwd)\s*[:：=]\s*([^\s]+)", line, re.I)
                if match:
                    value = match.group(1)
                    if value.startswith("http"):
                        value = value.rsplit("/", 1)[-1]
                    values.append(value)
        return {"datas": list(dict.fromkeys(values))}

    def _targets_untrusted_document(self, question: str) -> bool:
        action = re.search(r"完成|执行|运行|写入|创建|修改|删除|修复", question, re.I)
        if not action:
            return False
        normalized = normalize(question)
        for doc in self.index.documents:
            if not doc.metadata.get("restricted"):
                continue
            filename = Path(doc.path).name
            stem = Path(filename).stem
            if normalize(filename) in normalized or (len(stem) >= 2 and normalize(stem) in normalized):
                return True
        return False

    @staticmethod
    def _snippets(candidates: list[Document], question: str) -> list[str]:
        terms = [token for token in re.findall(r"[\u4e00-\u9fff]{2,}|[a-zA-Z0-9_.-]{2,}", question) if len(token) > 1]
        results: list[str] = []
        for doc in candidates[:10]:
            text = " ".join(str(doc.text or "").split())
            position = min((text.casefold().find(term.casefold()) for term in terms if text.casefold().find(term.casefold()) >= 0), default=0)
            snippet = text[max(0, position - 80): position + 240]
            if snippet:
                results.append(f"{doc.path}: {snippet}")
        return results

    @staticmethod
    def _static_result(candidates: list[Document], question: str) -> str | None:
        document = next((doc for doc in candidates if doc.suffix == "py"), None)
        if not document:
            return None
        try:
            tree = ast.parse(document.text)
        except SyntaxError:
            return None
        values: list[str] = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "print":
                literals = []
                for arg in node.args:
                    try:
                        literals.append(str(ast.literal_eval(arg)))
                    except (ValueError, TypeError):
                        literals = []
                        break
                if literals:
                    values.append(" ".join(literals))
        return "\n".join(values) if values else None


def read_questions(path: Path) -> list[dict[str, Any]]:
    text = path.read_text(encoding="utf-8-sig")
    fenced = re.search(r"```(?:json)?\s*(.*?)```", text, re.I | re.S)
    payload = fenced.group(1) if fenced else text
    raw = payload.strip()
    try:
        value = json.loads(raw)
    except json.JSONDecodeError:
        # Accept the common hand-edited Markdown mistake: adjacent objects
        # in an array without the separating comma.
        repaired = re.sub(r"(\})\s*(\{)", r"\1,\2", raw)
        value = json.loads(repaired)
    if not isinstance(value, list):
        raise ValueError(f"Question file must contain a JSON array: {path}")
    return value
