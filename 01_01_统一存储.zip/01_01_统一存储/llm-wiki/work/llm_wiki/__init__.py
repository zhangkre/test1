"""Offline, safety-first document wiki."""

__version__ = "1.0.0"
