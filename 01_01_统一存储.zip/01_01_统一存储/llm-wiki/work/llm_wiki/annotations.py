from __future__ import annotations

import re

from .models import Annotation


TODO_RE = re.compile(r"\btodo\b\s*[：:]\s*(?P<todo>.*?)(?=(?:[,，;；]\s*to\s*[：:])|$)", re.I)
TO_RE = re.compile(r"(?:^|[,，;；]\s*)to\s*[：:]\s*(?P<to>.*?)(?=(?:[,，;；]\s*end[_\s-]*date\s*[：:])|$)", re.I)
DATE_RE = re.compile(r"end[_\s-]*date\s*[：:]\s*(?P<date>\d{4}[-/.]?\d{2}[-/.]?\d{2})", re.I)
CODE_COMMENT_RE = re.compile(
    r"(?://|#|/\*+|<!--)\s*(?P<body>.*?(?:TODO.*?|需要.*?|待.*?|优化.*?|修复.*?|重构.*?))(?:\*/|-->)?$",
    re.I | re.M,
)


def parse_annotation(text: str, kind: str = "comment", location: str | None = None) -> Annotation:
    clean = " ".join(str(text or "").replace("\x00", " ").split()).strip(" */#<->")
    todo = TODO_RE.search(clean)
    owner = TO_RE.search(clean)
    date = DATE_RE.search(clean)
    return Annotation(
        text=(todo.group("todo").strip(" ,，;；") if todo else clean),
        kind="todo" if todo else kind,
        author=owner.group("to").strip(" ,，;；") if owner else None,
        end_date=re.sub(r"\D", "", date.group("date")) if date else None,
        location=location,
    )


def extract_code_annotations(text: str) -> list[Annotation]:
    text = str(text or "")
    found: list[Annotation] = []
    seen: set[tuple[str, int]] = set()
    for match in CODE_COMMENT_RE.finditer(text):
        body = match.group("body").strip()
        line = text.count("\n", 0, match.start()) + 1
        key = (body, line)
        if key not in seen:
            found.append(parse_annotation(body, "comment", f"line:{line}"))
            seen.add(key)
    return found
