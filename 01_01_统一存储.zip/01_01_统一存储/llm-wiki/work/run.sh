#!/usr/bin/env sh
set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

if command -v python3.11 >/dev/null 2>&1; then
  exec python3.11 "$SCRIPT_DIR/main.py" "$@"
fi
if command -v python3 >/dev/null 2>&1; then
  exec python3 "$SCRIPT_DIR/main.py" "$@"
fi
if command -v python >/dev/null 2>&1; then
  exec python "$SCRIPT_DIR/main.py" "$@"
fi

echo "Python 3.11 or newer was not found." >&2
exit 127
