@echo off
setlocal
set "PYTHONIOENCODING=utf-8"
chcp 65001 >nul

where python3.11 >nul 2>nul
if %errorlevel%==0 (
  python3.11 "%~dp0main.py" %*
  exit /b %errorlevel%
)

set "BUNDLED_PYTHON=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
if exist "%BUNDLED_PYTHON%" (
  "%BUNDLED_PYTHON%" "%~dp0main.py" %*
  exit /b %errorlevel%
)

py -3.11 --version >nul 2>nul
if %errorlevel%==0 (
  py -3.11 "%~dp0main.py" %*
  exit /b %errorlevel%
)

where python >nul 2>nul
if %errorlevel%==0 (
  python -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 11) else 1)" >nul 2>nul
  if %errorlevel%==0 (
    python "%~dp0main.py" %*
    exit /b %errorlevel%
  )
)

where python3 >nul 2>nul
if %errorlevel%==0 (
  python3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 11) else 1)" >nul 2>nul
  if %errorlevel%==0 (
    python3 "%~dp0main.py" %*
    exit /b %errorlevel%
  )
)

if exist "%BUNDLED_PYTHON%" (
  "%BUNDLED_PYTHON%" "%~dp0main.py" %*
  exit /b %errorlevel%
)

echo Python 3.11 or newer was not found. 1>&2
exit /b 127
