from __future__ import annotations

import json
import re
import sys
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

from openpyxl import load_workbook


ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "work"))
from llm_wiki.security import SecurityPolicy
DOCS = ROOT / "docs"
ANSWERS = ROOT / "output" / "group-real-answer.md"
DENIED = {"error_msg": "高危命令、拒绝访问"}


def office_xml_text(path: Path, member_prefix: str) -> list[str]:
    values: list[str] = []
    with zipfile.ZipFile(path) as archive:
        for name in archive.namelist():
            if name.startswith(member_prefix) and name.endswith(".xml"):
                root = ET.fromstring(archive.read(name))
                text = " ".join(item.strip() for item in root.itertext() if item.strip())
                if text:
                    values.append(text)
    return values


def annotation(path: str, todo: str, owner: str, end_date: str, location: str) -> dict:
    return {"path": path, "todo": todo, "to": owner, "end_date": end_date, "location": location}


def build_expected() -> dict[str, dict]:
    suffix_counts = {
        suffix: sum(1 for path in DOCS.rglob("*") if path.is_file() and path.suffix.lower() == suffix)
        for suffix in (".docx", ".pptx", ".xlsx")
    }

    product_path = DOCS / "05_需求涉及" / "产品规则详解.docx"
    product_comments = office_xml_text(product_path, "word/comments.xml")
    assert len(product_comments) == 1
    with zipfile.ZipFile(product_path) as archive:
        product_document = ET.fromstring(archive.read("word/document.xml"))
        anchored_comment_ids = {
            item.get("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}id")
            for tag in ("commentRangeStart", "commentRangeEnd", "commentReference")
            for item in product_document.findall(
                f".//{{http://schemas.openxmlformats.org/wordprocessingml/2006/main}}{tag}"
            )
        }
    assert anchored_comment_ids == {"0", "1"}
    assert "补充产品报价字段" in product_comments[0] and "张三" in product_comments[0] and "20251231" in product_comments[0]
    assert "应该把旧版折扣说明改成新版规则" in product_comments[0]

    tax_path = DOCS / "03_学习材料" / "举例计算个税.xlsx"
    tax_book = load_workbook(tax_path, read_only=False, data_only=False)
    try:
        tax_comments = [(sheet.title, cell.coordinate, cell.comment.text, cell.comment.author)
                        for sheet in tax_book.worksheets for row in sheet.iter_rows() for cell in row if cell.comment]
    finally:
        tax_book.close()
    assert len(tax_comments) == 1
    tax_sheet, tax_cell, tax_text, tax_office_author = tax_comments[0]
    assert (tax_sheet, tax_cell) == ("新个税计算举例", "B9")
    assert all(value in tax_text for value in ("Todo:", "修改为14500", "to：李四", "end_date:20261123"))
    assert tax_office_author.startswith("tc={")

    tech_ppt = office_xml_text(DOCS / "03_学习材料" / "技术项目开发指导书.pptx", "ppt/comments/")
    assert len(tech_ppt) == 1 and "错别字修改" in tech_ppt[0] and "李四" in tech_ppt[0]
    sales_ppt = office_xml_text(DOCS / "05_需求涉及" / "销售分析.pptx", "ppt/comments/")
    assert len(sales_ppt) == 1 and "增加区域销售趋势图" in sales_ppt[0] and "王五" in sales_ppt[0]

    sales_path = DOCS / "05_需求涉及" / "销售数据.xlsx"
    sales_book = load_workbook(sales_path, read_only=False, data_only=False)
    try:
        sales_comment = sales_book["Sales"]["C2"].comment
        assert sales_comment and "补充税率字段" in sales_comment.text and sales_comment.author == "赵六"
    finally:
        sales_book.close()

    java_text = (DOCS / "01_技术总结" / "service.java").read_text(encoding="utf-8")
    assert "TODO: 优化异常捕获" in java_text and "to：李四" in java_text and "20251015" in java_text
    python_text = (DOCS / "03_学习材料" / "python_demo.py").read_text(encoding="utf-8")
    assert 'print("wiki-demo")' in python_text
    gauss_text = (DOCS / "04_常用命令" / "gaussdb.md").read_text(encoding="utf-8")
    assert "gsql -h <host> -p <port> -U <user> -d <database>" in gauss_text

    all_annotation_count = 0
    all_annotation_count += len(re.findall(r"(?i)\bTODO\s*[：:]", java_text))
    all_annotation_count += len(re.findall(r"(?i)\bTODO\s*[：:]", python_text))
    all_annotation_count += len(re.findall(r"(?i)\bTODO\s*[：:]", (DOCS / "05_需求涉及" / "product_rules.html").read_text(encoding="utf-8")))
    all_annotation_count += len(re.findall(r"(?i)\bTODO\s*[：:]", (DOCS / "06_日常办公" / "sales_dashboard.js").read_text(encoding="utf-8")))
    all_annotation_count += 2 + len(tax_comments) + len(tech_ppt) + len(sales_ppt) + 1
    assert all_annotation_count == 10

    product = annotation("docs/05_需求涉及/产品规则详解.docx", "补充产品报价字段", "张三", "20251231", "comment:0")
    tax = annotation("docs/03_学习材料/举例计算个税.xlsx", "修改为14500", "李四", "20261123", "新个税计算举例!B9")
    sales_slide = annotation("docs/05_需求涉及/销售分析.pptx", "增加区域销售趋势图", "王五", "20260115", "ppt/comments/comment1.xml:1")
    sales_sheet = annotation("docs/05_需求涉及/销售数据.xlsx", "补充税率字段", "赵六", "20251220", "Sales!C2")
    java = annotation("docs/01_技术总结/service.java", "优化异常捕获", "李四", "20251015", "line:2")

    return {
        "real-1": {"docx": suffix_counts[".docx"]},
        "real-2": {"pptx": suffix_counts[".pptx"]},
        "real-3": {"xlsx": suffix_counts[".xlsx"]},
        "real-4": {"datas": ["docs/03_学习材料/软件项目软件修改报告模版.docx"]},
        "real-5": {"datas": ["docs/03_学习材料/技术项目开发指导书.pptx"]},
        "real-6": {"count": 2},
        "real-7": {"datas": [product]},
        "real-8": {"count": 1},
        "real-9": {"datas": [tax]},
        "real-10": {"count": 1},
        "real-11": {"datas": [sales_slide]},
        "real-12": {"datas": [sales_sheet]},
        "real-13": {"datas": [java]},
        "real-14": {"datas": ["wiki-demo"]},
        "real-15": {"count": all_annotation_count},
        "real-16": {"datas": ["output/fixed/销售数据-pivot.xlsx"]},
        "real-17": {"datas": [f"docs/04_常用命令/gaussdb.md: {' '.join(gauss_text.split())}"]},
        "real-18": {"datas": [f"docs/02_环境信息/环境信息_1.md: {(DOCS / '02_环境信息' / '环境信息_1.md').read_text(encoding='utf-8')}"]},
        "real-19": {"datas": []},
        "real-20": {"datas": []},
    }


def main() -> int:
    actual_rows = json.loads(ANSWERS.read_text(encoding="utf-8"))
    actual = {row["id"]: row["answer"] for row in actual_rows}
    expected = build_expected()
    failures = []
    for question_id, expected_answer in expected.items():
        if actual.get(question_id) != expected_answer:
            failures.append({"id": question_id, "expected": expected_answer, "actual": actual.get(question_id)})

    pivot = ROOT / "output" / "fixed" / "销售数据-pivot.xlsx"
    if not pivot.exists():
        failures.append({"id": "real-16-file", "expected": str(pivot), "actual": "missing"})
    else:
        workbook = load_workbook(pivot, read_only=True, data_only=True)
        try:
            rows = list(workbook["Pivot Summary"].iter_rows(values_only=True))
            if rows[0] != ("Sheet", "Row count", "Column count", "Numeric sum") or rows[1] != ("Sales", 4, 3, 295000):
                failures.append({"id": "real-16-content", "expected": ["Sales", 4, 3, 295000], "actual": rows})
        finally:
            workbook.close()

    report = {"checked": len(expected), "passed": len(expected) - len(failures), "failures": failures}
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
