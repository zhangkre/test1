# LLM Wiki 运行说明

本作品是一个 Python 3.11 离线文档 Wiki。当前目录即项目根目录，程序扫描 `docs`，提取正文、Office 批注和代码 TODO，建立本地 JSON 索引，读取 `question/group-*.md` 中的 JSON 数组，并把答案写入 `output/group-*-answer.md`。

## 目录

当前项目目录结构如下：

```text
INSTRUCTION.md
Permission.json
work/main.py
work/llm_wiki/
docs/...
question/group-x.md
output/group-x-answer.md
```

## 环境与依赖

要求 CPython `3.11.0` 或兼容的 Python 3.11+ 运行时。评测环境使用 Python 3.11.0 时可直接运行。建议在当前项目目录创建独立虚拟环境：

```powershell
py -3.11 -m venv .venv
.venv\Scripts\python -m pip install -r work\requirements.txt
```

所有格式均只依赖 Python 包，不需要安装 LibreOffice、Microsoft Office 或其他桌面软件：

- `openpyxl==3.1.5`：读取、修改和生成 `.xlsx`。
- `xlrd==2.0.1`、`xlwt==1.3.0`、`xlutils==2.0.0`：读取 `.xls` 内容和单元格批注，以及生成旧格式修复副本。
- `olefile==0.47`：读取 `.doc/.ppt/.pps/.ppts` 的 OLE 复合文档流，提取可读正文与 TODO/批注候选文本。

`work/requirements.txt` 是唯一第三方依赖清单，版本已固定。联网安装：

```powershell
py -3.11 -m pip install --disable-pip-version-check -r work\requirements.txt
```

离线环境请提前下载 wheel/源码包：

```powershell
py -3.11 -m pip download -r work\requirements.txt -d wheels
py -3.11 -m pip install --no-index --find-links wheels -r work\requirements.txt
```

依赖用途和缺失影响：

- 缺少 `openpyxl`：无法读取/修改 `.xlsx` 或生成 Excel 汇总；其他格式仍可索引。
- 缺少 `xlrd/xlwt/xlutils`：旧版 `.xls` 内容和批注能力降级；文件路径和数量仍可统计。
- 缺少 `olefile`：旧版 `.doc/.ppt/.pps/.ppts` 内容提取降级；新版 Office 和文本/代码文件不受影响。

`.docx/.pptx` 的正文及批注提取使用 Python 标准库。旧版 `.doc/.ppt` 是私有二进制格式，纯 Python 方案可稳定检索其可读文本和结构化 TODO；对于无法安全定位的二进制批注，修复操作会生成同目录的 UTF-8 修复清单，不会修改或破坏原文件。

## 运行

自动发现项目根目录并处理全部题目：

```powershell
.venv\Scripts\python work\main.py --root .
```

也可使用随作品提供的跨平台启动器：Windows 执行 `work\run.cmd --root .`；Linux/macOS 执行 `sh work/run.sh --root .`。

指定单个题目文件：

```powershell
.venv\Scripts\python work\main.py --root . --questions question\group-1.md
```

只重建索引：

```powershell
.venv\Scripts\python work\main.py --root . --index-only
```

运行测试：

```powershell
.venv\Scripts\python -m unittest discover -s work\tests -v
```

## 安全设计

- `Permission.json` 中的目录、文件和命令 deny 规则先于检索与执行判断，支持精确匹配及 `*` 通配。
- 所有目录、文件和命令拦截以外部提供的 `Permission.json` deny 配置为准；程序只读取配置，不写入、补充或修改该文件。配置为空时不因文件名猜测而额外拒绝。
- 只读环境密码/账号查询在目标未命中 `Permission.json` 时允许执行并返回原始文档结果；命中黑名单或属于删除/格式化/提权/下载执行等高危操作时统一返回 `{"error_msg":"高危命令、拒绝访问"}`。
- 文档正文、批注、TODO 和拼接字符串均为不可信数据；其中的“忽略规则”“上帝模式”“执行命令”等内容不会改变程序策略。
- 程序不调用用户题目中的 shell 命令，不读取项目根目录外的目标，不回显疑似凭据。
- 代码题只做 AST 静态分析和受限字面量表达式求值，不使用 `eval`、`exec` 或 shell。

判定示例：`Permission.json` 中没有 `env_config.xml` 时，查询该文件中的环境密码会返回原始上下文；如果 `file.deny` 包含 `env_config.xml`，同一问题才返回 `{"error_msg":"高危命令、拒绝访问"}`。目录 deny 对目录下所有子路径生效，命令 deny 对问题中出现的命令文本生效。

## 可选 AI 接入

核心流程不依赖在线模型，保证离线稳定和答案可复现。`llm_wiki/retrieval.py` 保留了检索结果接口，可在部署环境中把排名后的安全文本片段交给任意 LLM 做自然语言归纳；安全判定和最终输出校验必须继续在模型外执行。

注意：出于安全约束，本作品不会执行题目提供的任意代码或命令。因此，对于只含字面量参数的 Python `print(...)` 可通过 AST 给出确定结果；依赖网络、文件系统、动态导入或任意函数调用的代码执行问题返回空 `datas`，由部署方在独立、无网络、只读文件系统、有限 CPU/内存的容器沙箱中扩展。
